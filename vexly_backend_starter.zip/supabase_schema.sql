-- Vexly backend foundation for Supabase (PostgreSQL).
-- Run only in a NEW Supabase project. Review before applying to an existing database.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (username ~ '^[A-Za-z0-9_]{3,24}$'),
  display_name text not null default '',
  bio text not null default '' check (char_length(bio) <= 500),
  avatar_path text,
  telegram_username text,
  is_verified boolean not null default false,
  is_admin boolean not null default false,
  is_blocked boolean not null default false,
  created_at timestamptz not null default now()
);

-- Private contact details are separated from public profile data.
create table if not exists public.private_contacts (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  phone text,
  phone_public boolean not null default false,
  updated_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 3 and 80),
  description text not null check (char_length(description) between 1 and 2000),
  price numeric(12,2) not null check (price >= 0),
  currency text not null default 'RUB',
  category text not null check (category in ('Товары','Услуги','Цифровое','Для школы','Обмен')),
  image_paths text[] not null default '{}',
  status text not null default 'active' check (status in ('active','hidden','removed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, listing_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete set null,
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  seller_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  check (buyer_id <> seller_id),
  unique (listing_id, buyer_id, seller_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 3000),
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  listing_id uuid references public.listings(id) on delete cascade,
  reported_user_id uuid references public.profiles(id) on delete cascade,
  reason text not null check (char_length(reason) between 3 and 1000),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  moderator_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  check (listing_id is not null or reported_user_id is not null)
);

create index if not exists listings_status_created_idx on public.listings(status, created_at desc);
create index if not exists listings_seller_idx on public.listings(seller_id);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at);

alter table public.profiles enable row level security;
alter table public.private_contacts enable row level security;
alter table public.listings enable row level security;
alter table public.favorites enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.reports enable row level security;

-- Helper: admin status is read from server-controlled profile row.
create or replace function public.is_vexly_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.is_admin = true and p.is_blocked = false
  );
$$;

-- Public profile rows contain no phone number; private contacts are isolated below.
drop policy if exists "profiles public read" on public.profiles;
create policy "profiles public read" on public.profiles for select
using (true);

drop policy if exists "profile owner update safe fields" on public.profiles;
create policy "profile owner update safe fields" on public.profiles for update
using (auth.uid() = id or public.is_vexly_admin())
with check (auth.uid() = id or public.is_vexly_admin());

-- Server-side guard: users cannot grant themselves admin/verification or remove a block.
create or replace function public.protect_profile_privileges()
returns trigger language plpgsql security definer
set search_path = public
as $$
begin
  if auth.uid() is not null and not public.is_vexly_admin() then
    if new.is_admin is distinct from old.is_admin
       or new.is_verified is distinct from old.is_verified
       or new.is_blocked is distinct from old.is_blocked then
      raise exception 'Only Vexly administrators may change admin, verification, or block status';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists protect_profile_privileges_trigger on public.profiles;
create trigger protect_profile_privileges_trigger
before update on public.profiles
for each row execute procedure public.protect_profile_privileges();

drop policy if exists "private contacts owner read" on public.private_contacts;
create policy "private contacts owner read" on public.private_contacts for select
using (user_id = auth.uid() or public.is_vexly_admin());
drop policy if exists "private contacts owner insert" on public.private_contacts;
create policy "private contacts owner insert" on public.private_contacts for insert
with check (user_id = auth.uid());
drop policy if exists "private contacts owner update" on public.private_contacts;
create policy "private contacts owner update" on public.private_contacts for update
using (user_id = auth.uid() or public.is_vexly_admin())
with check (user_id = auth.uid() or public.is_vexly_admin());

drop policy if exists "profile insert own" on public.profiles;
create policy "profile insert own" on public.profiles for insert
with check (auth.uid() = id and is_admin = false and is_verified = false and is_blocked = false);

drop policy if exists "active listings public read" on public.listings;
create policy "active listings public read" on public.listings for select
using (status = 'active' or seller_id = auth.uid() or public.is_vexly_admin());

drop policy if exists "seller create listing" on public.listings;
create policy "seller create listing" on public.listings for insert
with check (auth.uid() = seller_id and not exists (
  select 1 from public.profiles p where p.id = auth.uid() and p.is_blocked = true
));

drop policy if exists "seller update listing" on public.listings;
create policy "seller update listing" on public.listings for update
using (seller_id = auth.uid() or public.is_vexly_admin())
with check (seller_id = auth.uid() or public.is_vexly_admin());

drop policy if exists "seller delete listing" on public.listings;
create policy "seller delete listing" on public.listings for delete
using (seller_id = auth.uid() or public.is_vexly_admin());

drop policy if exists "favorites own" on public.favorites;
create policy "favorites own" on public.favorites for all
using (user_id = auth.uid() or public.is_vexly_admin())
with check (user_id = auth.uid());

drop policy if exists "conversation participants read" on public.conversations;
create policy "conversation participants read" on public.conversations for select
using (buyer_id = auth.uid() or seller_id = auth.uid() or public.is_vexly_admin());

drop policy if exists "buyer starts conversation" on public.conversations;
create policy "buyer starts conversation" on public.conversations for insert
with check (buyer_id = auth.uid() and buyer_id <> seller_id);

drop policy if exists "messages participants read" on public.messages;
create policy "messages participants read" on public.messages for select
using (
  public.is_vexly_admin() or exists (
    select 1 from public.conversations c
    where c.id = conversation_id and (c.buyer_id = auth.uid() or c.seller_id = auth.uid())
  )
);

drop policy if exists "participants send messages" on public.messages;
create policy "participants send messages" on public.messages for insert
with check (
  sender_id = auth.uid() and exists (
    select 1 from public.conversations c
    where c.id = conversation_id and (c.buyer_id = auth.uid() or c.seller_id = auth.uid())
  )
);

drop policy if exists "reporter creates report" on public.reports;
create policy "reporter creates report" on public.reports for insert
with check (reporter_id = auth.uid());

drop policy if exists "reporter or admin reads reports" on public.reports;
create policy "reporter or admin reads reports" on public.reports for select
using (reporter_id = auth.uid() or public.is_vexly_admin());

drop policy if exists "admin manages reports" on public.reports;
create policy "admin manages reports" on public.reports for update
using (public.is_vexly_admin()) with check (public.is_vexly_admin());

-- Create profile after email signup. Username should be collected in signup metadata.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer
set search_path = public
as $$
declare
  requested_username text;
begin
  requested_username := coalesce(new.raw_user_meta_data->>'username', '');
  if requested_username !~ '^[A-Za-z0-9_]{3,24}$' then
    requested_username := 'user_' || substr(replace(new.id::text, '-', ''), 1, 12);
  end if;
  insert into public.profiles (id, username, display_name)
  values (new.id, requested_username, coalesce(new.raw_user_meta_data->>'display_name',''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_vexly on auth.users;
create trigger on_auth_user_created_vexly
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- SECURITY NOTE:
-- Do NOT set is_admin directly from the browser. First owner admin must be granted
-- from the Supabase SQL editor by the project owner after signup:
-- update public.profiles set is_admin = true where id = '<your-auth-user-uuid>';
-- Keep service_role keys out of HTML and mobile apps.
-- Payment provider integration is intentionally not included here.
